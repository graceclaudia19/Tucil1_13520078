# Word Search Puzzle

## Program Description 
Program ini dapat mencari kata-kata yang terdapat dalam word search puzzle. Algoritma yang digunakan pada program ini merupakan algoritma brute force. Pencarian kata dilakukan dengan arah ke kiri, kanan, atas, bawah, diagonal ke kiri atas, diagonal ke kanan atas, diagonal ke kiri bawah, dan diagonal ke  kanan bawah.
<br> 

## How to Use
1. Siapkan file dengan ekstension .txt untuk puzzle yang ingin disolve dengan format puzzle word search diatas lalu diberi selang enter satu kali ke kata-kata yang ingin dicari
2. Masukkan file ke folder test atau bisa juga menggunakan test case yang ada
3. Jalankan program
4. Saat program meminta input file, input ke terminal file yang ingin disolve dengan menulis "{namafile}.txt" misal: small1.txt
5. Tunggu sampai program mengeluarkan output, selamat mencoba!

## Author
Grace Claudia - 13520078 - K03
<br>
[More From Author](https://github.com/graceclaudia19)